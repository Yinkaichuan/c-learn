﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20210923B
{
    class Program
    {
        static void Main(string[] args)
        {
            //2.Variables(變數)
            //f(x,y)=x+y
            //f(4,5)=9
            //f(1,9)=10
            //2a.Defining Variables(declarartion,宣告資料型態)
            //int x;
            //int y;
            int x, y;
            //2b.Initializing Variables
            x = 4;
            y = 9;
            Console.WriteLine("x+y=" + (x + y));
            x++;
            y++;
            Console.WriteLine("x+y=" + (x + y));
            x = 92;
            y = 80;
            x--;
            y--;
            Console.WriteLine("x+y=" + (x + y));

            //1.Constant(常數)String(字串)
            //Console.Write("Ahoy! 110資一乙");
            //Console.WriteLine("Ahoy! 110IM1B");
            //Console.Write("Ahoy! pekora peko");
            //Console.WriteLine("Ahoy! 110IM1BBBB");
            //Console.WriteLine("11+9=" + (11 + 9));
            //Console.WriteLine("11-9=" + (11 - 9));
            //Console.WriteLine("11*9=" + (11 * 9));
            //Console.WriteLine("11+9=" + (11 + 9));
            //Console.WriteLine("11/9=" + (11 / 9));
            //Console.WriteLine("11.2/9.1=" + (11.2 / 9.1));
            //Console.WriteLine("11%9=" +(11 %9));
            //Console.WriteLine("3^12=" + Math.Pow(3,12));
            //Console.WriteLine("144^1/2=" + Math.Pow(144, 1.0/2.0));
            //Console.WriteLine("123456789*987654321=" +((long)12345678 * 987654321));
            Console.ReadKey();
        }
    }
}
