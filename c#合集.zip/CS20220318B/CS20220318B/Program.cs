﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20220318B
{
    class Program
    {
        static void Main(string[] args)
        {
            Eratostosnes PN=new Eratostosnes();
            PN.Create();

            while (true)
            {
                
                try
                {
                    Console.WriteLine("\n\n"+DateTime.Now);
                    Console.Write("[A]Factorial[？？] [B]How many prime numbers[？？]  [C]Prime Number[？] [E]Eratostosnes[？]");
                    string[] line= Console.ReadLine().Split(' ');
                    if (line[0] == "")  return;
                    string which = line[0];
                    int start;
                    int last;
                    int temp;
                    double startime, endtime;
                    checked
                    {
                        switch (which)
                        {
                            case "A":
                                {
                                     start = int.Parse(line[1]);
                                     last = int.Parse(line[2]);
                                    
                                    if (start>last)
                                    {
                                        temp = last;
                                        last = start;
                                        start = temp;
                                    }           
                                    for (int n = start; n <= last; n++)
                                    {
                                        if (Factorial(n) == -1)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine(n + "!值須 >=0");
                                            Console.ForegroundColor = ConsoleColor.White;
                                        }
                                        else Console.WriteLine(n + "!=" + Factorial(n));
                                    }
                                    break;
                                }

                            case "B":
                                Console.WriteLine("Prime Number？？(Between two Number)1 7919\nPrime Number？？(Between two Number)2147400000 2147483646\nPrime Number？？(Between two Number)2140000000 2147483646");
                                string[] two=Console.ReadLine().Split(' ');
                                int x=int.Parse(two[0]);
                                int y=int.Parse(two[1]);
                                int no = 0;
                                
                                startime = System.DateTime.Now.TimeOfDay.TotalSeconds;

                                for (int i =x;i<=y;i++)
                                {
                                    //if (PrimeYN(i))
                                    if(PN.Test(i))
                                    {
                                        no++;
                                        Console.WriteLine("P" + no + "=" + i);
                                    }
                                }
                                endtime = DateTime.Now.TimeOfDay.TotalSeconds;
                                Console.WriteLine("兩數間共" +no+"個質數;"+"計時:" + Math.Round(-(startime - endtime), 3) + "秒");

                                break;
                            case "C":
                                {
                                    decimal nth = 0;
                                    decimal nn = 0;
                                    decimal Number =decimal.Parse(line[1]);
                                    

                                    startime = System.DateTime.Now.TimeOfDay.TotalSeconds;
                                    while (nth<Number)
                                    {
                                        //if (PrimeYesNo(nn))
                                         if (PrimeYN((int)nn))
                                            {
                                            nth++;
                                            Console.WriteLine("P" + nth + "=" + nn);
                                        }
                                        nn++;
                                    }
                                    endtime = DateTime.Now.TimeOfDay.TotalSeconds;
                                    Console.WriteLine("計算"+Number+"個質數計:"+Math.Round(-(startime-endtime),3)+"秒");

                                    break;
                                }

                            case "E":
                                {
                                    
                                    int number = int.Parse(line[1]);
                                    startime = System.DateTime.Now.TimeOfDay.TotalSeconds;
                                    int[] PrimeNo = new int[number + 1];

                                    PrimeNo[1] = 2; PrimeNo[2] = 3; PrimeNo[3] = 5; PrimeNo[4] = 7;
                                    int N = 11;
                                    int np, sr;

                                    Console.WriteLine("P1=2\n"+ "P2=3\n"+ "P3=5\n"+ "P4=7\n");
                                    for (int n=5;n<=number;n++)
                                    {
                                        sr = (int)Math.Sqrt(N) + 1;
                                        np = 1;
                                        while (sr>=PrimeNo[np])
                                        {
                                            if (N % PrimeNo[np] == 0)
                                            {
                                                N++;
                                                np = 1;
                                            }
                                            else np++;
                                        }
                                        PrimeNo[n] = N;
                                        Console.WriteLine("P"+n+"="+PrimeNo[n]);
                                        N++;
                                    }

                                    endtime = DateTime.Now.TimeOfDay.TotalSeconds;
                                    Console.WriteLine("計算" + number + "個質數計:" + Math.Round(-(startime - endtime), 3) + "秒");


                                    break;
                                }
                                
                            default: return;
                        }

                    }
                    }
                       
                catch (Exception EX)
                {
                    Console.ForegroundColor=ConsoleColor.Red;
                    Console.WriteLine(EX.Message);
                    Console.ForegroundColor = ConsoleColor.White;
                    return;
                }

                finally
                {
                    Console.WriteLine("Press any key to Exit");
                    Console.ReadKey();
                }
            }
        }
        static bool PrimeYesNo(decimal X)
        {
            
            if (X <= 1) return false;
            else if  (X == 2) return true;
            else if (X%2 == 0) return false;
            else
            {
                for(decimal i = 3;i<X; i+=2)
                {
                    if (X % i == 0) return false;
                    
                }
                return true;
            }

        }
        static bool PrimeYN(int X)
        {
            
            if (X <= 1) return false;
            else if (X == 2) return true;
            else if (X % 2 == 0) return false;
            else
            {
                int sr=(int)Math.Sqrt((double)X);
                for (int i = 3; i <= sr; i += 2)
                {
                    if (X % i == 0) return false;
                    
                }

                return true;
            }
            
        }


        static decimal Factorial(int X)
        {
            decimal f;
            if (X < 0) return -1;
            else if (X == 0 || X == 1) return 1;
            else
            {
                f = 1;
                for (int i = X; i > 0; i--)
                {
                    f = f * i;
                }
                return f;
            }

        }

        class Eratostosnes
        {
            public int[] PrimeNo=new int[100001];

            public void Create()
            {
                

                PrimeNo[1] = 2; PrimeNo[2] = 3; PrimeNo[3] = 5; PrimeNo[4] = 7;
                int N = 11;
                int np, sr;

                Console.WriteLine("P1=2\n" + "P2=3\n" + "P3=5\n" + "P4=7\n");
                for (int n = 5; n <= 100000; n++)
                {
                    sr = (int)Math.Sqrt(N) + 1;
                    np = 1;
                    while (sr >= PrimeNo[np])
                    {
                        if (N % PrimeNo[np] == 0)
                        {
                            N++;
                            np = 1;
                        }
                        else np++;
                    }
                    PrimeNo[n] = N;                   
                    N++;
                }
                Console.WriteLine("PrimeNO[1000]="+PrimeNo[1000]);
                Console.WriteLine("PrimeNO[100000]=" + PrimeNo[100000]);
                Console.WriteLine("PrimeNO[100000]^2=" + (long)PrimeNo[100000]* (long)PrimeNo[100000]);
            }
            public bool Test(int N)
            {
                int ptr = 1;
                if (N <2) return false;
                else if (N == 2) return true;
                else if (N % 2 == 0) return false;
                else
                {
                    int sr = (int)Math.Sqrt(N)+2;
                    while (sr>PrimeNo[ptr])
                    {
                        if (N % PrimeNo[ptr] == 0) return false;
                        else ptr++;
                    }

                    return true;
                }
            }
        }
        }
}
