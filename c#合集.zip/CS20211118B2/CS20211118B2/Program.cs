﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211118B2
{
    class Program
    {
        static void Main(string[] args)
        {
            string FM;
            double Wasist, Height, Weight, BMI;
            bool sex;

            while(true)
            {
                try
                {
                    Console.WriteLine("\n**************************************************\n");
                    Console.WriteLine(" BMI(Body Mass Index)");
                    Console.WriteLine("資料來源: http://zh.wikipedia.org/wiki/身高體重指數");
                    Console.WriteLine("\n==================================================\n");
                    Console.WriteLine(" 請輸入性別-女[Female](0/f/F)男[Male](1/m/M)？");
                    FM = Console.ReadLine();
                    checked
                    {
                        if(FM== "0"  ||  FM =="f" || FM == "F")
                        {
                            Console.WriteLine("性別: 女(false)");
                            sex = false;
                            
                        }
                        else if(FM == "1" || FM == "m" || FM == "M")
                        {
                            Console.WriteLine("性別: 男(True)");
                            sex = true;

                        }
                        else
                        {
                            Console.Write("性別選擇錯誤！");
                            //return;
                            //break;
                            continue;
                        }

                        Console.Write("請輸入腰圍(cm)?");
                        Wasist = double.Parse(Console.ReadLine());
                        Console.Write("請輸入身高(cm)?");
                        Height = double.Parse(Console.ReadLine());
                        Console.Write("請輸入體重(kg)?");
                        Weight = double.Parse(Console.ReadLine());

                        BMI = Math.Round(Weight / Math.Pow(Height / 100, 2),2);

                        if (BMI<= 18.5) 
                        {
                            Console.WriteLine(BMI+"體重過輕");
                        }
                        else if (BMI <= 23.9)
                        {
                            Console.WriteLine(BMI + "體重適中");
                        }
                        else if (BMI >24)
                        {
                            Console.WriteLine(BMI + "體重超重");
                        }
                        else if (BMI >= 28)
                        {
                            Console.WriteLine(BMI + "體重過重");
                        }



                        Console.WriteLine();
                    }



                }
                catch (Exception ex) 
                {
                    Console.WriteLine(ex);


                }
                finally
                {

                    Console.WriteLine(".........Pause(Press any key to continue)");

                }










            }

            Console.WriteLine("bye bye");
            Console.ReadKey();




        }
    }
}
