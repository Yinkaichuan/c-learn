﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CS20220401          
{
   internal class Program
    {
        static System.Threading.Thread threadA, threadB,threadC;
        static Random RN = new Random();
        static byte A,B, C,Nth;
        static int Sleeptime;

        static void Main(string[] args)
        {    
            while (true)
            {             
                try
                {
                    Console.Write("Press Y(y) for Continue Else for No？ Nth？ SleepTime(ms)？");
                    string []line= Console.ReadLine ().Split(' ');
                    Nth =byte.Parse (line[1]);
                    Sleeptime = int.Parse (line[2]);

                    if (line[0] == "Y" || line[0] == "y")
                    {
                        A = 0;B = 0;C = 0;
                        threadA = new Thread(new ThreadStart(IMA));
                        threadB = new Thread(new ThreadStart(IMB));
                        threadC = new Thread(new ThreadStart(IMC));

                        threadA.Start();
                        threadB.Start();
                        threadC.Start();




                    }
                    else return;


                }
                       
                catch (Exception EX)
                {
                    Console.ForegroundColor=ConsoleColor.Red;
                    Console.WriteLine(EX.Message);
                    Console.ForegroundColor = ConsoleColor.White;
                    return;
                }

                finally
                {
                    
                    Console.ReadKey();
                }
            }
        }
        private static void IMA()
        {
            while (true)
            {
                Thread.Sleep(RN.Next(100,Sleeptime));
                A++;
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("資一甲("+A+")"+System.DateTime.Now.ToLongTimeString().ToString());
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;
                if (A == Nth)
                {
                    threadB.Abort();
                    threadC.Abort();
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("資一甲Winner");
                    Console.ForegroundColor = ConsoleColor.White;
                    threadA.Abort();
                }
            }
        }
        private static void IMB()
        {
            while (true)
            {
                Thread.Sleep(RN.Next(100, Sleeptime));
                B++;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("資一乙(" + B + ")" + System.DateTime.Now.ToLongTimeString().ToString());
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;
                if (B == Nth)
                {
                    threadA.Abort();
                    threadC.Abort();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("資一乙Winner");                    
                    Console.ForegroundColor = ConsoleColor.White;
                    threadB.Abort();
                }
            }
        }
        private static void IMC()
        {
            while (true)
            {
                Thread.Sleep(RN.Next(100, Sleeptime));
                C++;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("資一丙(" + C + ")" + System.DateTime.Now.ToLongTimeString().ToString());
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;
                if (C == Nth)
                {
                    threadB.Abort();
                    threadA.Abort();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("資一丙Winner");
                    Console.ForegroundColor = ConsoleColor.White;
                    threadC.Abort();
                }
            }
        }

    }
}
