﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20220225B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random RN= new Random();
            while (true)
            {
                try
                {
                    checked
                    {
                        Console.WriteLine("\n\nINPUT 10 Students？");
                        Console.Write("INPUT number of Student？");

                        //int a0, a1, a2, a3, a4, a5, a6, a7, a8, a9;
                        //a0=RN.Next(1,101);
                        //a1 = RN.Next(1, 101);
                        //a2 = RN.Next(1, 101);
                        //a3 = RN.Next(1, 101);
                        //a4 = RN.Next(1, 101);
                        //a5 = RN.Next(1, 101);
                        //a6 = RN.Next(1, 101);
                        //a7 = RN.Next(1, 101);
                        //a8 = RN.Next(1, 101);
                        //a9 = RN.Next(1, 101);

                        string []line = Console.ReadLine().Split(' ');
                        int number = int.Parse(line[0]);
                        int[] score = new int[number];
                        for (int i = 0; i < number; i++) score[i] = RN.Next(0, 101);

                        Console.WriteLine("Unsorted Score:");
                        for (int i = 0; i < number; i++)
                        {
                            Console.Write(score[i] + ", ");
                        }

                        int temp;
                        for (int i =1;i<number;i++) //回合
                        {
                             for (int j=1;j<=number-i;j++) //比較
                            {
                                temp = score[j-1];
                                score[j - 1] = score[j];
                                score[j] = temp;
                            }
                             
                        }
                        Console.Write("Sorted Scores(Ascending)：");
                        for (int i = 0; i < number; i++) Console.Write(score[i]+", ");

                        Console.Write("Sorted Scores(Descending)：");
                        for (int i = number-1;i>=0; i--) Console.Write(score[i] + ", ");

                    }
                }
                catch (Exception EX)
                {
                    Console.WriteLine(EX.Message);
                    
                }

                finally
                {
                   
                }
            }
        }
    }
}
