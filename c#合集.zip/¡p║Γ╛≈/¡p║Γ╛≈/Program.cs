﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 計算機
{
    class Program
    {
        static void Main(string[] args)
        {
            decimal ans=0;
            while (true)
            {
               

                try
                {
                    Console.WriteLine("Tip: 僅限(+-*/%)，清除：C");
                    Console.WriteLine("=========================");
                    Console.WriteLine(ans);
                    Console.WriteLine("=========================");
                   string [] line = Console.ReadLine().Split(' ');

                    if(line[0] == "C")
                    {
                        Console.WriteLine(ans=0);
                    }
                    decimal old = ans;
                    ans =+  decimal.Parse(line[1]);
                    decimal num = decimal.Parse(line[1]);
                    switch(line[0])
                    {
                        case "+":
                            ans += num;
                            break;
                        case "-":
                            ans -= num;
                            break;
                        case "*":
                            ans *= num;
                            break;
                        case "/":
                            ans /= num;
                            break;
                        case "%":
                            ans %= num;
                            break;
                        case "C":
                            
                            break;
                    }

                    Console.WriteLine(old + " " + line[0] + " " + line[1] + " = " + ans );












                }
                catch(Exception EX)
                {
                    Console.WriteLine(EX.Message);
                }
                finally
                {

                }








            }






        }
    }
}
