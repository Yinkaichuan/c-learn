﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211021B
{
    class Program
    {
        static void Main(string[] args)
        {
            checked
            {
                //4.
                Console.WriteLine("Input X? Input Y?");
                string [] line=Console.ReadLine().Split(' ');
                Console.WriteLine(line[0]+ line[1]);
                Console.WriteLine(int.Parse(line[0]) + int.Parse(line[1]));


                //3.Readline
                //Console.WriteLine("Input = X");
                //string X = Console.ReadLine();
                //Console.WriteLine("Input = Y");
                //string Y = Console.ReadLine();
                //Console.WriteLine("X+Y=" +(X+Y));

                //Console.WriteLine("Input = X");
                //int X = int.Parse(Console.ReadLine());
                //Console.WriteLine("Input = Y");
                //int Y = int.Parse(Console.ReadLine());
                //Console.WriteLine("X+Y=" + (X + Y));

                //string Y = Console.ReadLine();
                //Console.WriteLine("X+Y=" + (X + Y));


                //2a.宣告

                //int x;
                //int y;

                //2b.指派
                //int x, y;
                //x = 9;
                //y = 10;
                //Console.WriteLine("x+y=" + (x + y));

                //int x = 9, y = 8;
                //Console.WriteLine("x+y="+(x+y));

                ////long a = 123456789012345678, b = 987654321098765432;
                //decimal a = 123456789012345678, b = 987654321098765432;
                //Console.WriteLine("a+b=" +(a+b));
                //Console.WriteLine("a-b=" + (a - b));
                ////Console.WriteLine("a*b=" + (a * b));
                //Console.WriteLine("a/b=" + (a / b));

                //int c= 2147483647;
                //int d = 4;
                ////Console.WriteLine("c+d="+(c+d)); overflow
                //Console.WriteLine("c-d="+(c-d));






                //int x = 1;
                //int y = 3;
                //Console.WriteLine("x+y=" + (x + y));
                //Console.WriteLine("x-y=" + (x - y));
                //Console.WriteLine("x*y=" + (x * y));
                //Console.WriteLine("x/y=" + (x / y));
                //Console.WriteLine("x^y=" + ma(x,y));



                //1.
                //Console.Write("好油喔 PEKO!!");
                //Console.WriteLine("ahoy!!");
                //Console.WriteLine("apex何時才能上大師?");


                //Console.WriteLine("1+2+3+4+5=?" + 1 + 2 + 3 + 4 + 5);
                //Console.WriteLine("1+2+3+4+5=?" + (1 + 2 + 3 + 4 + 5));
                //Console.WriteLine("(1+2+3+4+5)*5=?" + (1 + 2 + 3 + 4 + 5 * 5));
                //Console.WriteLine("(1+2+3+4+5)*5=?" + (1 + 2 + 3 + 4 + 5) * 5);
                //Console.WriteLine("(1+2+3+4+5)/5=?" + (1 + 2 + 3 + 4 + 5) / 5);


                //Console.WriteLine("1/9=?" + 1 / 9);
                //Console.WriteLine("1/9=?" + 1.0 / 9.0);


                //Console.WriteLine("1/9=(round)" + Math.Round(1.0 / 9.0, 1));
                //Console.WriteLine("1/9=(round)" + Math.Round(1.0 / 9.0, 2));
                //Console.WriteLine("1/9=(round)" + Math.Round(1.0 / 9.0, 0));

                //Console.WriteLine("嗨 老師");
                //Console.WriteLine("3^9=" + Math.Pow(3, 9));
                //Console.WriteLine("12^12=" + Math.Pow(12, 12));
                //Console.WriteLine("144^1/2=" + Math.Pow(144, 1/2));
                //Console.WriteLine("144^1/2=" + Math.Pow(144, 1.0/2.0));

                //Console.WriteLine("20%6=?" + 20 % 6);
                // Console.WriteLine("30%9=?" + 30 % 9);

                // https://www.tutorialspoint.com/cprogramming/index.htm

                //c#tutorial (Data type) (Variables)

                //Console.WriteLine("123*456="+(123*456));

                //Console.WriteLine("123456*654321=" + (123456 * 654321)); (溢位)
                // Console.WriteLine("123456*654321=" + ((long)123456 * 654321));
                // Console.WriteLine("123456*654321=" + (123456 * (long)654321));

                //Console.WriteLine("123456789*987654321=" + (123456789 * (long)987654321));
                //Console.WriteLine("1234567890*987654321=" + (1234567890 * (decimal)987654321));

                // Console.WriteLine("-2147483648-1=" + (-2147483648 -1 ));(overflow)
                //Console.WriteLine("2147483647+1=" + (2147483647+1));(overfiow)
                // Console.WriteLine("-2147483648-1=" + (-2147483648 - (long)1));
                // Console.WriteLine("2147483647+1=" + ((long)2147483647 + 1));

                //Console.WriteLine("-9223372036854775808-1=" + ((long)-9223372036854775808-1)); overfiow
                //Console.WriteLine("9223372036854775807+1=" + ((long)9223372036854775807+1));
                //Console.WriteLine("-9223372036854775808-1=" + ((decimal)-9223372036854775808 - 1));
                //Console.WriteLine("9223372036854775807+1=" + ((decimal)9223372036854775807+1));




                Console.ReadKey();


                
                
            }
        }
    }
}
