﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211201
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                
                try
                {
                    Console.WriteLine("\n\n"+DateTime.Now);
                    Console.Write("[A]Factorial[？？]  [B]Fibonacci[？？]  [C]Prime Number[？]  [D]GCD[LCM] = (Input Number：？？)");
                    string[] line= Console.ReadLine().Split(' ');
                    if (line[0] == "")  return;
                    string which = line[0];
                    checked
                    {
                        switch (which)
                        {
                            case "A":
                                {
                                    int fact;
                                    int N = int.Parse(line[1]);
                                    if (N == 0 || N == 1) Console.WriteLine(N + "！= 1");
                                    else if (N < 0) Console.WriteLine(N+"！= N!之N值須 >= 0");
                                    else
                                    {
                                        for(int i = 1; i <= N; i++)
                                        {
                                            fact = 1;

                                            fact = fact * i;
                                            Console.WriteLine(N+"!="+fact);

                                        }




                                    }

                                    break;
                                }
                            case "B":
                                {



                                    break;
                                }

                            case "C":
                                {

                                    break;
                                }
                            case "D":
                                {


                                    break;
                                }

                            default: return;
                                



                        }

                    }
                    }
                       
                catch (Exception EX)
                {
                    Console.ForegroundColor=ConsoleColor.Red;
                    Console.WriteLine(EX.Message);
                    Console.ForegroundColor = ConsoleColor.White;
                    return;
                }

                finally
                {
                    Console.WriteLine("Press any key to Exit");
                    Console.ReadKey();
                }
            }
        }
    }
}
