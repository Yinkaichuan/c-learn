﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TA03
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try { 
            Console.WriteLine("8==============================D");
            Console.WriteLine("依所選功能輸出，");
            Console.WriteLine("正整數Ｘ～Ｙ之費氏數列。");
            Console.WriteLine("8==============================D");
            Console.WriteLine("功能選項：");
            Console.WriteLine("Ａ：正常輸出");
            Console.WriteLine("Ｂ：倒敘輸出");
            Console.WriteLine("Ｃ：只輸出偶數");
            Console.WriteLine("Ｄ：只輸出奇數");
            Console.WriteLine("Ｅ：標示質數");
            Console.WriteLine("8==============================D");
            Console.Write("Ｘ、Ｙ、功能＝");
           string[] line= Console.ReadLine().Split(' ');
            string which = Console.ReadLine();
            which = line[2];
            decimal start = decimal.Parse(line[0]);
            decimal last = decimal.Parse(line[1]);
            decimal temp;
            decimal i = 0;
                    switch (which)
                    {
                        case "A":
                            {
                                for (i = start; i <= last; i++)
                                {
                                    if (start > last)
                                    {
                                        temp = last;
                                        last = start;
                                        start = temp;
                                    }
                                    if (A(i) == -1)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine(i + "小於0");
                                        Console.ForegroundColor = ConsoleColor.White;
                                    }
                                    else if (A(i) == 1) Console.WriteLine(i + ".       1");
                                    else Console.WriteLine(i + ".       " + A(i));
                                }
                                break;
                            }
                        case "B":
                            {
                                for (i = start; i <= last; i--)
                                {
                                    if (start > last)
                                    {
                                        temp = last;
                                        last = start;
                                        start = temp;
                                    }
                                    if (A(i) == -1)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine(i + "小於0");
                                        Console.ForegroundColor = ConsoleColor.White;
                                    }
                                    else if (A(i) == 1) Console.WriteLine(i + ".       1");
                                    else Console.WriteLine(i + ".       " + A(i));
                                }


                                break;
                            }
                        case "C":
                            {

                                break;
                            }
                        case "D":
                            {

                                break;
                            }
                        case "E":
                            {

                                break;
                            }
                    }   
                }
                catch(Exception ex) { }
                finally
                {
                    Console.WriteLine("請按任意鍵繼續...");
                    Console.ReadKey();
                }
            }






















        }

        static decimal A(decimal X)
        {
            if (X <= 0) return -1;
            else if (X == 1 || X == 0) return 1;
            else
            {
                decimal n = 2;
                decimal f0 = 0;
                decimal f1 = 1;
                decimal f = 0;

                while (n <= X)
                {
                    f = f0 + f1;
                    f0 = f1;
                    f1 = f;
                    n++;
                    
                }
                return f;
            }

        }

        

    }
    




}
