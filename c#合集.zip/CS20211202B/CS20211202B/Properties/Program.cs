﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211201
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                
                try
                {
                    Console.WriteLine("\n\n"+DateTime.Now);
                    Console.Write("[A]Factorial[？？]  [B]Fibonacci[？？]  [C]Prime Number[？]  [D]GCD[LCM] = (Input Number：？？)");
                    string[] line= Console.ReadLine().Split(' ');
                    if (line[0] == "")  return;
                    string which = line[0];
                    checked
                    {
                        switch (which)
                        {
                            case "A":
                                {
                                    Decimal fact;
                                    //int N = int.Parse(line[1]);
                                    int start = int.Parse(line[1]);
                                    int last = int.Parse(line[2]);
                                    int temp;
                                    if (start>last)
                                    {
                                        temp = last;
                                        last = start;
                                        start = temp;
                                    }
                                 //1.nested loops
                                    //for (int n = start;n<=last;n++)
                                    //{
                                    //    if (n < 0) Console.WriteLine(n + "!值須 >=0");
                                    //    else if (n == 0 || n == 1) Console.WriteLine(n + "!=1");
                                    //    else
                                    //    {
                                    //        fact = 1;
                                    //        for (int i = n; i > 0; i--)
                                    //        {
                                    //            fact = fact * i;

                                    //        }
                                    //        Console.WriteLine(n + "!=" + fact);
                                    //    }
                                    //}
                                  //2.
                                    for (int n = start; n <= last; n++)
                                    {
                                        if (Factorial(n) == -1)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine(n + "!值須 >=0");
                                            Console.ForegroundColor = ConsoleColor.White;
                                        }
                                        else Console.WriteLine(n + "!=" + Factorial(n));

                                    }









                                    //if (N == 0 || N == 1) Console.WriteLine(N + "！= 1");
                                    //else if (N < 0) Console.WriteLine(N+"！= N!之N值須 >= 0");




                                    //else
                                    //{
                                    //1.for
                                    //    fact = 1;
                                    //    for (int i = 1; i <= N; i++)
                                    //    {
                                    //        fact = fact * i;
                                    //        Console.WriteLine(i + "!=" + fact);

                                    //    }

                                    //    //2.
                                    //    //for (int i = N; i >0; i--)
                                    //    //{
                                    //    //    fact = fact * i;
                                    //    //    Console.WriteLine(i + "!=" + fact);

                                    //    //}

                                        //3.While
                                    //    //int i = 1;
                                    //    //while (i <= N)
                                    //    //{

                                    //    //    fact = fact * i;
                                    //    //        Console.WriteLine(i+"!="+fact);
                                    //    //    i++;
                                    //    //}

                                    //    //4.
                                    //    //int i = N;
                                    //    //while (i > 0)
                                    //    //{

                                    //    //    fact = fact * i;
                                    //    //    Console.WriteLine(i + "!=" + fact);
                                    //    //    i--;
                                    //    //}



                                    //}

                                    break;
                                }
                            case "B":
                                {



                                    break;
                                }

                            case "C":
                                {

                                    break;
                                }
                            case "D":
                                {


                                    break;
                                }

                            default: return;
                                



                        }

                    }
                    }
                       
                catch (Exception EX)
                {
                    Console.ForegroundColor=ConsoleColor.Red;
                    Console.WriteLine(EX.Message);
                    Console.ForegroundColor = ConsoleColor.White;
                    return;
                }

                finally
                {
                    Console.WriteLine("Press any key to Exit");
                  
                }
            }
        }
        static decimal Factorial(int X)
        {
            decimal f;
            if (X < 0) return -1;
            else if (X == 0 || X == 1) return 1;
            else
            {
                f = 1;
                for (int i = X; i > 0; i--)
                {
                    f = f * i;
                }
                return f;
            }



        }

    }
}
