﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20220331B
{
    class Program
    {
        static void Main(string[] args)
        {
            Random RN = new Random();
            int Nth; //第幾個樂透碼
            int[] LC = new int[8];
            while (true)
            {
                
                try
                {
                    Console.Write("請輸入需幾組樂透碼[6+1(特別號)]？Max. Numbe of Lotto[7-49]？Time for one code generated？");
                    string []line= Console.ReadLine ().Split(' ');
                    int a=int.Parse(line[0]);
                    int b = int.Parse(line[1]);
                    int c = int.Parse(line[2]);
                    if (a < 0 || b < 7 || b > 49 || c < 0) goto skip;

                    for (int i=1;i<=a;i++)
                    {
                        
                        
                        Nth = 1;
                        bool test;
                        while (Nth <= 7)
                        {
                            test = true;
                            while (test)
                            {
                                test=false;
                                LC[Nth] = RN.Next(7, b + 1);
                                System.Threading.Thread.Sleep(c);
                                Console.Write(LC[Nth]);

                                for (int t=1;t<Nth;t++)
                                {
                                    if (LC[Nth]==LC[t])
                                    {
                                        Console.Write(String.Empty.PadLeft(2));
                                        test = true;
                                        break;
                                    }

                                }
                            }
                            Console.Write("*"+String.Empty.PadLeft(2));
                            


                            Nth++;
                        }


                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.Write(i+". ");
                        for (int j=1;j<=7;j++)
                        {
                            Console.Write(LC[j] + string.Empty.PadLeft(2));
                        }
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.Black;
                        Console.WriteLine(); Console.WriteLine();
                    }



                skip:;
                }
                       
                catch (Exception EX)
                {
                    Console.ForegroundColor=ConsoleColor.Red;
                    Console.WriteLine(EX.Message);
                    Console.ForegroundColor = ConsoleColor.White;
                    return;
                }

                finally
                {
                    Console.WriteLine("Press any key to Exit");
                    Console.ReadKey();
                }
            }
        }
       

        
        }
}
