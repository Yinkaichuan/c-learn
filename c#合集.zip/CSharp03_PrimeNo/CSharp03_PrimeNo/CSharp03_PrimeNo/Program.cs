﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp03_PrimeNo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double Start = 0, Finish = 0;
            int no = 0;
            while (true)
            {
                try
                {
                    checked
                    {                        
                        Console.WriteLine("Prime Number？？(Between two Number)2147000000 2147483647");                       
                        string[] Line = Console.ReadLine().Split(' ');   
                        if (Line[0] == "") break;
                        int X = int.Parse(Line[0]);
                        //int Y = int.Parse(Line[1]);                       
                        int Y = int.MaxValue;           //Max. of int：2147483647
                        no = 0;   //number of prime number
                        Start = DateTime.Now.TimeOfDay.TotalSeconds;
                        for (int i = X; i <= Y; i++)  //int i <= 2147483646(7)                        
                        {
                            if (PrimeYesNo(i))
                            {
                                no++;
                                Console.WriteLine("P" + no + "= " + i);
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                finally
                {
                    Finish = DateTime.Now.TimeOfDay.TotalSeconds;
                    Console.WriteLine("\n共計 " + no + " 個質數：" + Math.Round(Finish - Start, 3) + "秒");                    
                }
            }
        }

        static bool PrimeYesNo(int N)            // 4s (2147000000 - 2147483646 ) 
        //static bool PrimeYesNo(decimal N)      // 37s 
        {
            int SquareRoot = (int)(Math.Sqrt(N) + 1);
            if (N <= 1) return false;
            else if (N == 2) return true;
            else if (N % 2 == 0) return false;
            else
            {
                //for (int i = 3; i * i <= N; i += 2)           //int 12s 
                for (int i = 3; i <= SquareRoot; i += 2)      //int 0.9s                               
                {
                    if (N % i == 0) return false;
                }
                return true;
            }
        }
    }
}
