﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wqee
{
    class Program
    {
        static void Main(string[] args)
        {
            Random RN = new Random();
            while (true)
            {
                try
                {
                    checked
                    {
                        Console.WriteLine("成績分級？A[100-85]；B[84-70]；C[69-60]；Fail[59-30](基本分30)");
                        Console.WriteLine("Press <Enter> for Return");
                        Console.Write("C#學期成績模擬(人數)？");
                        string line = Console.ReadLine();
                        int N = int.Parse(line);
                        int o = 0;
                        int i = 1;
                        int p = 0;
                        double a = 0;
                        double b = 0;
                        double c = 0;
                        double d = 0;
                        int math;
                        string h = null;
                        if (N == 0)
                        {
                            return;
                        }
                        while (i <= N)
                        {

                            math = RN.Next(30, 101);

                            Console.Write(i + "." + math + "...");

                            if (math >= 85)
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("A");
                                Console.ForegroundColor = ConsoleColor.White;
                                if (math == 100)
                                {
                                    h = (i - 1) + "(100)" + ";";

                                }
                                p = p + 1;
                                a = math + a;
                                i++;
                            }
                            else if (math <= 84 && math >= 70)
                            {
                                Console.WriteLine("B");
                                p = p + 1;
                                b = math + b;
                                i++;
                            }
                            else if (math <= 69 && math >= 60)
                            {
                                Console.WriteLine("C");
                                p = p + 1;
                                d = math + d;
                                i++;
                            }
                            else if (math <= 59 && math >= 30)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("fail");
                                Console.ForegroundColor = ConsoleColor.White;
                                o = o + 1;
                                c = math + c;
                                i++;
                            }
                            

                        }

                        Console.WriteLine("全班平均成績" + Math.Round(((a + c + d + b) / N), 1));
                        Console.WriteLine("PASS[>=60]人數：" + p);
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Fail[< 60]人數：" + o);
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("滿分名單："+h );
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
                catch (Exception EX)
                {
                    Console.WriteLine(EX.Message);
                    return;
                }

                finally
                {

                }
            }
        }
    }
}
