﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211118B2
{
    class Program
    {
        static void Main(string[] args)
        {
            string FM;
            double Wasist, Height, Weight, BMI;
            bool sex;

            while(true)
            {
                try
                {
                    Console.WriteLine("\n**************************************************\n");
                    Console.WriteLine(" BMI(Body Mass Index)");
                    Console.WriteLine("資料來源: http://zh.wikipedia.org/wiki/身高體重指數");
                    Console.WriteLine("\n==================================================\n");
                    Console.WriteLine(" 請輸入性別-女[Female](0/f/F)男[Male](1/m/M)？");
                    FM = Console.ReadLine();
                    checked
                    {
                        if(FM== "0"  ||  FM =="f" || FM == "F")
                        {
                            Console.WriteLine("性別: 女(false)");
                            sex = false;
                            
                        }
                        else if(FM == "1" || FM == "m" || FM == "M")
                        {
                            Console.WriteLine("性別: 男(True)");
                            sex = true;

                        }
                        else
                        {
                            Console.Write("性別選擇錯誤！");
                            //return;
                            //break;
                            continue;
                        }

                        Console.Write("請輸入腰圍(cm)?");
                        Wasist = double.Parse(Console.ReadLine());
                        Console.Write("請輸入身高(cm)?");
                        Height = double.Parse(Console.ReadLine());
                        Console.Write("請輸入體重(kg)?");
                        Weight = double.Parse(Console.ReadLine());

                        BMI =(Weight / Math.Pow(Height / 100, 2));
                        double Q = Math.Round(BMI, 1);
                        Console.WriteLine("BMI(體質數["+BMI+"])"+ "="+ Q);

                        //1.二分法
                        //if (BMI < 18.5) 
                        //{
                        //    Console.WriteLine("體重過輕");
                        //}
                        //else
                        //{
                        //    Console.WriteLine("體重正常或超重");
                        //}
                        //2.三分法
                        //if (BMI < 18.5)
                        //{
                        //    Console.WriteLine("體重過輕");
                        //}
                        //else if (BMI<24) 
                        //{
                        //    Console.WriteLine("體重正常");
                        //}
                        //else
                        //{
                        //    Console.WriteLine("體重超重");
                        //}


                        if (BMI < 18.5)
                        {
                            Console.WriteLine(Q + "體重過輕");
                            if (sex && Wasist >= 95d || !sex && Wasist >= 90d)
                                //if (sex == true&&Wasist>=95d|| sex == false && Wasist >= 90d) 
                            {
                                Console.WriteLine("腰圍" + Wasist + "危險"); 
                            }
                        }
                        else if (Q >= 18.5&& Q < 24d)
                        {
                            Console.WriteLine(Q + "體重適中");
                            if (sex && Wasist >= 85d&&Wasist<=95d || !sex && Wasist >= 80d&&Wasist<=90d)
                            {
                                Console.WriteLine("腰圍" + Wasist + "危險");
                            }
                                else if (sex && Wasist >= 95d || !sex && Wasist >= 90d)
                            {
                                Console.WriteLine("腰圍"+Wasist+"高危險");
                            }
                        }
                        else if (Q >= 24d&& Q < 28d)
                        {
                            Console.WriteLine(Q + "體重超重");
                            if(sex && Wasist >= 95d || !sex && Wasist >= 90d)
                            {
                                Console.WriteLine("腰圍" + Wasist + "極高危險");
                            }
                        }
                        if (sex && Wasist <85d || !sex && Wasist < 80d)
                        {
                            Console.WriteLine("腰圍" + Wasist + "危險");
                        }
                        else if (sex && Wasist >= 85d&&Wasist<=95d || !sex && Wasist >= 80d&&Wasist<=90d)
                        {
                            Console.WriteLine("腰圍" + Wasist + "高危險");
                        }



                        //else if (BMI >= 28d )   //d=double
                        //{
                        //    Console.WriteLine(BMI + "體重肥胖");
                        //}
                        else
                        {
                            Console.WriteLine(Q + "體重肥胖");
                            if(sex && Wasist >= 95d || !sex && Wasist >= 90d)
                            {
                                Console.WriteLine("危險");
                            }
                        }


                        Console.WriteLine();
                    }



                }
                catch (Exception ex) 
                {
                    Console.WriteLine(ex);


                }
                finally
                {

                    Console.WriteLine(".........Pause(Press any key to continue)");

                }










            }

            Console.WriteLine("bye bye");
            Console.ReadKey();




        }
    }
}
