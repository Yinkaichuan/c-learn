﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                String[] line = Console.ReadLine().Split(' ');
                long a = long.Parse(line[0]);
                long b = long.Parse(line[1]);
                long q =a / b ;
                

                Console.WriteLine(a+"+"+b+"="+(a+b));
                Console.WriteLine(a + "*" + b + "=" + (a * b));
                Console.WriteLine(a + "-" + b + "=" + (a - b));
                if (a < 0||b<0)
                {
                    if (r > 0)
                    {
                        r - 1;
                    }
                    long r = (q % b) + 1;
                    Console.WriteLine(a + "/" + b + "=" + (q) + "..." + (r));
                }
                else
                {
                    long r = (q % b) - 1;
                    Console.WriteLine(a + "/" + b + "=" + (q) + "..." + (r));
                }

            }

        }
    }
}
