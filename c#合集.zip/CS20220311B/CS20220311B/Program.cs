﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20220311B
{
    
    internal class Program
    {
        struct student
        {
            public int s;
            public string name;
            public int a;
            public int c;
            public int d;
            public int total;
        }
        static void Main(string[] args)
        {
            Random RN= new Random();
            while (true)
            {
                try
                {
                    checked
                    {
                        Console.WriteLine("\n\n僅限使用單一個一維陣列");
                        Console.Write("INPUT number of Student？ Max. Length of Last Name？");
                        string []line = Console.ReadLine().Split(' ');
                        int number = int.Parse(line[0]);
                        int namelength = int.Parse(line[1]);
                        string name;
                        int a, c, d, total;
                        Console.WriteLine("序號. 姓名：計概 + C# + 資料結構 = 總分");
                        //string []st = new string[number];
                        
                        student []st= new student[number];


                        for(int i = 1; i <= number; i++)
                        {
                            st[i-1].s= i;
                            st[i - 1].name =((char)RN.Next(65, 91)).ToString();
                            st[i - 1].a = RN.Next(0,101);
                            st[i - 1].c = RN.Next(0, 101);
                            st[i - 1].d = RN.Next(0, 101);
                            st[i - 1].total = st[i - 1].a + st[i - 1].c + st[i - 1].d;

                            for(int j = 1; j <= RN.Next(1,namelength); j++)
                            {
                                st[i - 1].name += ((char)RN.Next(97, 123)).ToString();
                            }

                            
                            Console.WriteLine(st[i-1].s+". "+ st[i - 1].name+ ":"+st[i - 1].a+" + "+ st[i - 1].c+" + "+ st[i - 1].d+" = "+ st[i - 1].total);

                        }
                        Console.WriteLine("======================================================");
                        int right, left,pos1,pos2,pos3,pos4,temp;
                        string f,g,str;
                        Console.Write("Sorting by Score(Descending)|Name(Ascending)|SN|[4]平均分數與資料結構皆及格？");
                        string []which= Console.ReadLine().Split(' ');
                        switch (which[0])
                        {
                            case "S":
                                {
                                    for (int i = 1; i < number; i++) //回合
                                    {
                                        for (int j = 1; j <= number - i; j++) //比較
                                        {
                                            
                                            if (st[j - 1].total > st[j].total)
                                            {
                                                temp = st[j - 1].s;
                                                st[j - 1].s = st[j].s;
                                                st[j].s = temp;

                                                str = st[j - 1].name;
                                                st[j - 1].name = st[j].name;
                                                st[j].name = str;

                                                temp = st[j - 1].a;
                                                st[j - 1].a = st[j].a;
                                                st[j].a = temp;

                                                temp = st[j - 1].c;
                                                st[j - 1].c = st[j].c;
                                                st[j].c = temp;

                                                temp = st[j - 1].d;
                                                st[j - 1].d = st[j].d;
                                                st[j].d = temp;

                                                temp = st[j - 1].total;
                                                st[j - 1].total = st[j].total;
                                                st[j].total = temp;

                                            }
                                        }

                                    }
                                    for (int k = number - 1; k >= 0; k--)
                                    {
                                        Console.WriteLine(st[k].s + ". " + st[k].name + ":" + st[k].a + " + " + st[k].c + " + " + st[k].d + " = " + st[k].total);
                                    }

                                    break;
                                }
                            case "N":
                                {
                                    for (int i = 1; i < number; i++) //回合
                                    {
                                        for (int j = 1; j <= number - i; j++) //比較
                                        {
                                            
                                            if (string.Compare(st[j-1].name, st[j].name) > 0) //F>G
                                            {
                                                temp = st[j - 1].s;
                                                st[j - 1].s = st[j].s;
                                                st[j].s = temp;

                                                str = st[j - 1].name;
                                                st[j - 1].name = st[j].name;
                                                st[j].name = str;

                                                temp = st[j - 1].a;
                                                st[j - 1].a = st[j].a;
                                                st[j].a = temp;

                                                temp = st[j - 1].c;
                                                st[j - 1].c = st[j].c;
                                                st[j].c = temp;

                                                temp = st[j - 1].d;
                                                st[j - 1].d = st[j].d;
                                                st[j].d = temp;

                                                temp = st[j - 1].total;
                                                st[j - 1].total = st[j].total;
                                                st[j].total = temp;
                                            }

                                        }
                                    }
                                    for (int k = 0; k < number; k++)
                                    {
                                        Console.WriteLine(st[k].s + ". " + st[k].name + ":" + st[k].a + " + " + st[k].c + " + " + st[k].d + " = " + st[k].total);
                                    }
                                    break;
                                }
                            case "SN":
                                {
                                    for (int i = 1; i < number; i++) //回合
                                    {
                                        for (int j = 1; j <= number - i; j++) //比較
                                        {

                                            if (st[j - 1].total > st[j].total)
                                            {
                                                temp = st[j - 1].s;
                                                st[j - 1].s = st[j].s;
                                                st[j].s = temp;

                                                str = st[j - 1].name;
                                                st[j - 1].name = st[j].name;
                                                st[j].name = str;

                                                temp = st[j - 1].a;
                                                st[j - 1].a = st[j].a;
                                                st[j].a = temp;

                                                temp = st[j - 1].c;
                                                st[j - 1].c = st[j].c;
                                                st[j].c = temp;

                                                temp = st[j - 1].d;
                                                st[j - 1].d = st[j].d;
                                                st[j].d = temp;

                                                temp = st[j - 1].total;
                                                st[j - 1].total = st[j].total;
                                                st[j].total = temp;

                                            }
                                            else if (st[j-1].total == st[j].total)
                                            {
                                                for (int t = 1; t < number; t++) //回合
                                                {
                                                    for (int k = 1; k <= number - k; k++) //比較
                                                    {

                                                        if(string.Compare(st[j - 1].name, st[j].name) < 0) //F<G
                                            {
                                                            temp = st[j - 1].s;
                                                            st[j - 1].s = st[j].s;
                                                            st[j].s = temp;

                                                            str = st[j - 1].name;
                                                            st[j - 1].name = st[j].name;
                                                            st[j].name = str;

                                                            temp = st[j - 1].a;
                                                            st[j - 1].a = st[j].a;
                                                            st[j].a = temp;

                                                            temp = st[j - 1].c;
                                                            st[j - 1].c = st[j].c;
                                                            st[j].c = temp;

                                                            temp = st[j - 1].d;
                                                            st[j - 1].d = st[j].d;
                                                            st[j].d = temp;

                                                            temp = st[j - 1].total;
                                                            st[j - 1].total = st[j].total;
                                                            st[j].total = temp;
                                                        }

                                                    }
                                                }
                                            }
                                        }
                                    }

                                    for (int k = number - 1; k >= 0; k--)
                                    {
                                        Console.WriteLine(st[k].s + ". " + st[k].name + ":" + st[k].a + " + " + st[k].c + " + " + st[k].d + " = " + st[k].total);
                                    }

                                    break;
                                }
                            case "4":
                                {
                                    for (int i = 0; i < number; i++)
                                    {
                                        
                                        Console.Write(st[i].s + ". " + st[i].name + ":" + st[i].a + " + " + st[i].c + " + ");
                                        if (st[i].total >= 180 && st[i].d >= 60)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Green;
                                        }
                                        Console.WriteLine(st[i].d + " = " + st[i].total+"("+ Math.Round(st[i].total/3.0,1)+")");
                                        Console.ForegroundColor = ConsoleColor.White;
                                    }
                                    break;
                                }
                            case "9":
                                {
                                    for (int i = 0; i < number; i++)
                                    {
                                        
                                        Console.Write(st[i].s + ". " + st[i].name + ":");

                                        if (st[i].a >= 60 && st[i].c >= 60 && st[i].d >= 60)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Green;
                                        }
                                        Console.Write(st[i].a + " + " + st[i].c + " + " + st[i].d);
                                        Console.ForegroundColor = ConsoleColor.White;
                                        Console.WriteLine(" = " + st[i].total);
                                    }

                                    break;
                                }
                            default:
                                break;

                        }


                    }
                }
                catch (Exception EX)
                {
                    Console.WriteLine(EX.Message);
                }

                finally
                {
                    
                }
            }
        }
    }
}
