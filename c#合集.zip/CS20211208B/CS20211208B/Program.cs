﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211208B
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                
                try
                {
                    Console.WriteLine("\n\n"+DateTime.Now);
                    Console.Write("[A]Factorial[？？]  [B]Fibonacci[？？]  [C]Prime Number[？]  [D]GCD[LCM] = (Input Number：？？)");
                    string[] line= Console.ReadLine().Split(' ');
                    if (line[0] == "")  return;
                    string which = line[0];
                    int start;
                    int last;
                    int temp;       
                    checked
                    {
                        switch (which)
                        {
                            case "A":
                                {
                                     start = int.Parse(line[1]);
                                     last = int.Parse(line[2]);
                                    
                                    if (start>last)
                                    {
                                        temp = last;
                                        last = start;
                                        start = temp;
                                    }           
                                    for (int n = start; n <= last; n++)
                                    {
                                        if (Factorial(n) == -1)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine(n + "!值須 >=0");
                                            Console.ForegroundColor = ConsoleColor.White;
                                        }
                                        else Console.WriteLine(n + "!=" + Factorial(n));
                                    }
                                    break;
                                }
                            case "B":
                                {
                                     start = int.Parse(line[1]);
                                     last = int.Parse(line[2]);
                                     
                                    if (start > last)
                                    {
                                        temp = last;
                                        last = start;
                                        start = temp;
                                    }
                                    for (int n = start; n <= last; n++)
                                    {
                                        if (Fibonacci(n) == -1)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine("Fib("+n+") = Fib(n)之n >= 0");
                                            Console.ForegroundColor = ConsoleColor.White;
                                        }
                                        else Console.WriteLine("Fib("+n+") = " + Fibonacci(n));
                                    }








                                    break;
                                }

                            case "C":
                                {

                                    break;
                                }
                            case "D":
                                {


                                    break;
                                }

                            default: return;
                                



                        }

                    }
                    }
                       
                catch (Exception EX)
                {
                    Console.ForegroundColor=ConsoleColor.Red;
                    Console.WriteLine(EX.Message);
                    Console.ForegroundColor = ConsoleColor.White;
                    return;
                }

                finally
                {
                    Console.WriteLine("Press any key to Exit");
                  
                }
            }
        }
        static decimal Factorial(int X)
        {
            decimal f;
            if (X < 0) return -1;
            else if (X == 0 || X == 1) return 1;
            else
            {
                f = 1;
                for (int i = X; i > 0; i--)
                {
                    f = f * i;
                }
                return f;
            }



        }

        static decimal Fibonacci(int X)
        {
            if (X < 0) return -1;
            else if (X ==0) return 0;
            else if (X == 1) return 1;
            else
            {
                decimal f0 = 0;
                decimal f1 = 1;
                decimal fn=0 ;
                decimal f = 2;
                while (f<=X)
                {
                    fn = f0 + f1;
                    f0 = f1;
                    f1 = fn;
                    f++;
                }
                return fn;

            }
        }
        }
}
