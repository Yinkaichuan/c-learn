﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20220303B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random RN= new Random();
            while (true)
            {
                try
                {
                    checked
                    {
                        Console.WriteLine("\n\n僅限使用單一個一維陣列");
                        Console.Write("INPUT number of Student？ Max. Length of Last Name？");
                        string []line = Console.ReadLine().Split(' ');
                        int number = int.Parse(line[0]);
                        int namelength = int.Parse(line[1]);
                        string name;
                        int a, c, d, total;
                        Console.WriteLine("序號. 姓名：計概 + C# + 資料結構 = 總分");
                        string []st = new string[number];

                        for(int i = 1; i <= number; i++)
                        {
                            name =((char)RN.Next(65, 91)).ToString();
                            a = RN.Next(0,101);
                            c = RN.Next(0, 101);
                            d = RN.Next(0, 101);
                            total = a + c + d;

                            for(int j = 1; j <= RN.Next(1,namelength); j++)
                            {
                                name+= ((char)RN.Next(97, 123)).ToString();
                            }

                            st[i-1] = i + ". "+ name+ " : "+ a + " + " + c + " + " + d + " = " + total;
                            Console.WriteLine(st[i-1]);

                        }
                        Console.WriteLine("======================================================");
                        int right, left;
                        string str;
                        Console.Write("Sorting by Score(Descending)|Name(Ascending)|SN|[4]平均分數與資料結構皆及格？");
                        string []which= Console.ReadLine().Split(' ');
                        switch (which[0])
                        {
                            case "S":
                                {
                                    for (int i = 1; i < number; i++) //回合
                                    {
                                        for (int j = 1; j <= number - i; j++) //比較
                                        {
                                            left = int.Parse(st[j - 1].Substring(st[j - 1].IndexOf("=") + 2));
                                            right = int.Parse(st[j].Substring(st[j].IndexOf("=") + 2));
                                            if (left > right)
                                            {
                                                str = st[j - 1];
                                                st[j - 1] = st[j];
                                                st[j] = str;

                                            }

                                        }

                                    }
                                    for (int k = number - 1; k >= 0; k--)
                                    {
                                        Console.WriteLine(st[k]);
                                    }

                                    break;
                                }
                            case "N":
                                {


                                    break;
                                }
                            case "SN":
                                {


                                    break;
                                }
                            case "4":
                                {


                                    break;
                                }
                            default:
                                break;
                                
                        }


                    }
                }
                catch (Exception EX)
                {
                    Console.WriteLine(EX.Message);
                }

                finally
                {
                    
                }
            }
        }
    }
}
