﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211215B
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                
                try
                {
                    Console.WriteLine("\n\n"+DateTime.Now);
                    Console.Write("[A]Factorial[？？]  [B]Fibonacci[？？]  [C]Prime Number[？]  [D]GCD[LCM] = (Input Number：？？)");
                    string[] line= Console.ReadLine().Split(' ');
                    if (line[0] == "")  return;
                    string which = line[0];
                    int start;
                    int last;
                    int temp;       
                    checked
                    {
                        switch (which)
                        {
                            case "A":
                                {
                                     start = int.Parse(line[1]);
                                     last = int.Parse(line[2]);
                                    
                                    if (start>last)
                                    {
                                        temp = last;
                                        last = start;
                                        start = temp;
                                    }           
                                    for (int n = start; n <= last; n++)
                                    {
                                        if (Factorial(n) == -1)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine(n + "!值須 >=0");
                                            Console.ForegroundColor = ConsoleColor.White;
                                        }
                                        else Console.WriteLine(n + "!=" + Factorial(n));
                                    }
                                    break;
                                }
                            case "B":
                                {
                                     start = int.Parse(line[1]);
                                     last = int.Parse(line[2]);
                                     
                                    if (start > last)
                                    {
                                        temp = last;
                                        last = start;
                                        start = temp;
                                    }
                                    for (int n = start; n <= last; n++)
                                    {
                                        if (Fibonacci(n) == -1)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine("Fib(" + n + ") = Fib(n)之n >= 0");
                                            Console.ForegroundColor = ConsoleColor.White;
                                        }
                                        else
                                        {
                                            if (Fibonacci(n)%2==0) Console.WriteLine("Fib(" + n + ") = " + Fibonacci(n) + "{偶數}");
                                            else Console.WriteLine("Fib(" + n + ") = " + Fibonacci(n)+"[奇數]");
                                        }
                                    }

                                    break;
                                }

                            case "C":
                                {
                                    decimal nth = 0;
                                    decimal nn = 0;
                                    decimal number =decimal.Parse(line[1]);
                                    double startime, endtime;

                                    startime = System.DateTime.Now.TimeOfDay.TotalSeconds;
                                    while (nth<number)
                                    {
                                        if (PrimeYesNo(nn))
                                        {
                                            nth++;
                                            Console.WriteLine("P" + nth + "=" + nn);
                                        }
                                        nn++;
                                    }
                                    endtime = DateTime.Now.TimeOfDay.TotalSeconds;
                                    Console.WriteLine("計算"+number+"個質數計:"+Math.Round(startime-endtime,3)+"秒");

                                    break;
                                }
                            case "D":
                                {
                                    decimal X =decimal.Parse(line[1]);
                                    decimal Y = decimal.Parse(line[2]);
                                    Console.WriteLine("GCD("+X+","+Y+")="+GCD(X,Y)); 
                                    Console.WriteLine("LCM("+X+","+ Y+") ="+ LCM(X,Y));
                                    break;
                                }
                            default: return;
                        }

                    }
                    }
                       
                catch (Exception EX)
                {
                    Console.ForegroundColor=ConsoleColor.Red;
                    Console.WriteLine(EX.Message);
                    Console.ForegroundColor = ConsoleColor.White;
                    return;
                }

                finally
                {
                    Console.WriteLine("Press any key to Exit");
                    Console.ReadKey();
                }
            }
        }
        static bool PrimeYesNo(decimal X)
        {
            //3.
            //if (X <= 1) return false;
            //else if (X == 2) return true;
            //else if (X % 2 == 0) return false;
            //else
            //{
            //    //for (decimal i = 3; i < (decimal)Math.Pow((double)X,1.0/2.0); i += 2)
            //    //    for (decimal i = 3; i < (decimal)Math.Sqrt((double)X); i += 2)
            //    for (decimal i = 3; i*i <= X; i += 2)
            //    {
            //        if (X % i == 0) return false;
            //        Console.WriteLine(i);
            //    }
            //    return true;
            //}







            //2.少檢查偶數 比較快一點
            if (X <= 1) return false;
            else if  (X == 2) return true;
            else if (X%2 == 0) return false;
            else
            {
                for(decimal i = 3;i<X; i+=2)
                {
                    if (X % i == 0) return false;
                    Console.WriteLine(i);
                }
                return true;
            }

            //1.慢
            //if (X <= 1) return false;
            //else
            //{
            //    for (decimal i = 2;i<X;i++)
            //    {
            //        if (X % i == 0) return false;
            //    }
            //    return true;
            //}
        }


        static decimal GCD(decimal A,decimal B) 
        {
            if (A < 0) A = -A;
            if (B < 0) A = -B;
            decimal R;
            while (A%B!=0)
            {
                R = A % B;
                A = B;
                B = R;
            }
            return B;

        }
        static decimal LCM(decimal A, decimal B)
        {
            decimal C;
            C= Math.Abs(A * B) / GCD(A, B);

            return C;

        }


        static decimal Factorial(int X)
        {
            decimal f;
            if (X < 0) return -1;
            else if (X == 0 || X == 1) return 1;
            else
            {
                f = 1;
                for (int i = X; i > 0; i--)
                {
                    f = f * i;
                }
                return f;
            }

        }

        static decimal Fibonacci(int X)
        {
            if (X < 0) return -1;
            else if (X ==0) return 0;
            else if (X == 1) return 1;
            else
            {
                decimal f0 = 0;
                decimal f1 = 1;
                decimal fn=0 ;
                decimal f = 2;
                while (f<=X)
                {
                    fn = f0 + f1;
                    f0 = f1;
                    f1 = fn;
                    f++;
                }
                return fn;

            }
        }
        }
}
