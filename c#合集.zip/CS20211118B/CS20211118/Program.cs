﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211118B
{
    class Program
    {
        static void Main(string[] args)
        {
            int  chi, en, math, P1, P2,Total;
            Random RN = new Random();
            while (true)
            {
                try
                {
                    checked
                    {
                        Console.WriteLine("四技二專成績計算模擬[國文 英文 數學 專一 專二]");
                        Console.WriteLine("請選擇[A]Input單人五科分數[B]Input人數自動產生分數[其他鍵]結束 ？");
                        string which = Console.ReadLine();
                        switch(which)
                            {
                            case "A":
                                Console.WriteLine("Input 國文？英文？數學？專一？專二？");

                                string[] score  = Console.ReadLine().Split(' ');

                                chi = int.Parse(score[0]);
                                en = int.Parse(score[1]);
                                math = int.Parse(score[2]);
                                P1 = int.Parse(score[3]);
                                P2 = int.Parse(score[4]);
                                Total = chi + en + math + P1 * 2 + P2 * 2;

                                Console.WriteLine(chi+"+"+en+"+"+math+"+"+P1+"+"+P2+"*2"+"="+Total);
                                Console.Write(chi+"[國文]+" + en + "[英文]+" + math + "[數學]+" + P1 + "[專一*2]+" + P2 + "[專二*2]="+Total+"[總分]");
                                Console.WriteLine();
                                break;
                            case "B":
                                Console.WriteLine("考生人數？產生單筆資料速度(一秒 = 1000)？");

                                string[] item = Console.ReadLine().Split(' ');

                                int N = int.Parse(item[0]);
                                int speed = int.Parse(item[1]);

                                //for (init起始值; condition條件; increment)

                                //for (int i =1; i<=N; i++)
                                //{
                                //    chi = RN.Next(1,101);
                                //    en = RN.Next(1, 101);
                                //    math = RN.Next(1, 101);
                                //    P1 = RN.Next(1, 101);
                                //    P2 = RN.Next(1, 101);
                                //    Total = chi + en + math + P1 * 2 + P2 * 2;

                                //    Console.ForegroundColor = ConsoleColor.Yellow;
                                //    Console.BackgroundColor = ConsoleColor.Blue;
                                //    Console.Write(i+"."+chi + "[國文]+" + en + "[英文]+" + math + "[數學]+" + P1 + "[專一*2]+" + P2 + "[專二*2]=" + Total + "[總分]");
                                //    Console.WriteLine();
                                //    Console.ForegroundColor = ConsoleColor.White;
                                //    Console.BackgroundColor = ConsoleColor.Black;


                                //    System.Threading.Thread.Sleep(speed);
                                //}

                                int i = 1;
                                while (i <= N)
                                {
                                    chi = RN.Next(1, 101);
                                    en = RN.Next(1, 101);
                                    math = RN.Next(1, 101);
                                    P1 = RN.Next(1, 101);
                                    P2 = RN.Next(1, 101);
                                    Total = chi + en + math + P1 * 2 + P2 * 2;

                                    Console.ForegroundColor = ConsoleColor.Yellow;
                                    Console.BackgroundColor = ConsoleColor.Blue;
                                    Console.Write(i + "." + chi + "[國文]+" + en + "[英文]+" + math + "[數學]+" + P1 + "[專一*2]+" + P2 + "[專二*2]=" + Total + "[總分]");
                                    Console.WriteLine();
                                    Console.ForegroundColor = ConsoleColor.White;
                                    Console.BackgroundColor = ConsoleColor.Black;


                                    System.Threading.Thread.Sleep(speed);
                                    i++;


                                }


                                break;

                           default:
                                return;

                        }
                    }
                }
                catch(Exception EX)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(EX);
                    Console.ForegroundColor = ConsoleColor.White;
                }

                finally
                {
                    Console.WriteLine("try again \n\n");
                }
            }



        }
    }
}
