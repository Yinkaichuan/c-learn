﻿
while True:
    try:
        X,Y=input("Input X?Input Y? 9223372036854775807 9223372036854775807\n").split()
        print("X + Y = "+str(int(X)+int(Y)));
        print("X * Y = "+str(int(X)*int(Y)));
    except Exception as e:
        print(e)
    finally:
        print("C# Finally Hello 明新資管甲乙班!!\n")