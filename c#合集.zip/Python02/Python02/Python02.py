﻿while True:
    try:
        def Factorial(N):
            if N<0:
                print(str(N)+"! = N!之N值須>=0")
            else:
                F=1
                for i in range(1,N+1,1):
                    F=F*i
                print(str(N)+"! = "+str(F))
            return
        X,Y=input("Input X?Input Y?Factorial？？\n").split()
        if int(X) > int(Y):                      
           temp = Y 
           Y = X
           X = temp
        for n in range(int(X),int(Y)+1,1):
            Factorial(n)

    except Exception as e:
        print(e)
    finally:
        print("C# Finally Hello 明新資管甲乙班!!\n")
