﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211223B
{
    class Program
    {
        static void Main(string[] args)
        {
            


            while (true)
            {
                try
                {
                    checked 
                    {
                        int counter = 0;

                        for (int n1 = 1; n1 <= 9; n1++)
                        {
                            if (n1 % 2 != 0) continue;
                            for (int n2 = 1; n2 <= 9; n2++)
                            {
                                if (n2 == n1) continue;
                                for (int n3 = 1; n3 <= 9; n3++)
                                {
                                    if (n3 == n1 || n3 == n2) continue;
                                    for (int n4 = 1; n4 <= 9; n4++)
                                    {
                                        if (n4 == n1 || n4 == n2 || n4 == n3) continue;
                                        for (int n5 = 1; n5 <= 9; n5++)
                                        {
                                            if (n5 == n1 || n5 == n2 || n5 == n3 || n5 == n4) continue;
                                            decimal N1235 = (n1 + n2 + n3 + n5);
                                            for (int n6 = 1; n6 <= 9; n6++)
                                            {
                                                int a = (n4 * 100) + (n5 * 10) + n6;

                                                if (!PrimeYesNo(a)) continue;

                                                if (n6 == n1 || n6 == n2 || n6 == n3 || n6 == n4 || n6 == n5) continue;
                                                
                                                for (int n7 = 1; n7 <= 9; n7++)
                                                {
                                                    if (n7 == n1 || n7 == n2 || n7 == n3 || n7 == n4 || n7 == n5 || n7 == n6) continue;

                                                    decimal N2457 = (n2+n4+n5+n7);

                                                    for (int n8 = 1; n8 <= 9; n8++)
                                                    {
                                                        decimal N3568 = (n3+n5+n6+n8);
                                                        if (n8 == n1 || n8 == n2 || n8 == n3 || n8 == n4 || n8 == n5 || n8 == n6 || n8 == n7) continue;
                                                        
                                                        for (int n9 = 1; n9 <= 9; n9++)
                                                        {
                                                            if (n9 % 2 == 0) continue;

                                                            decimal N5789 = (n5+n7+n8+n9);


                                                            if (N1235 != N3568 || N3568 != N5789 || N5789 != N2457) continue;

                                                            
                                                            if (n9 == n1 || n9 == n2 || n9 == n3 || n9 == n4 || n9 == n5 || n9 == n6 || n9 == n7 || n9 ==n8) continue;
                                                            counter++;
                                                            Console.WriteLine("    "+n1);
                                                            Console.WriteLine("  "+n2 + "   " + n3);
                                                            Console.WriteLine(n4 + "   " + n5 + "   " + n6);
                                                            Console.WriteLine("  "+n7 + "   " + n8  );
                                                            Console.WriteLine("    "+n9 + "\n");
                                                        }

                                                    }

                                                }

                                            }

                                        }   
                                    }

                                }

                            }


                        }

                        Console.WriteLine(counter + " 組解");



                    }
                    
                }
                catch(Exception EX)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(EX);
                    Console.ForegroundColor = ConsoleColor.White;


                }
                finally
                {
                    Console.WriteLine("Press any key try again！\n");
                    Console.ReadKey();

                }

                



            }

        

            




        }
        static bool PrimeYesNo(decimal X)
        {
            //2.少檢查偶數 比較快一點
            if (X <= 1) return false;
            else if (X == 2) return true;
            else if (X % 2 == 0) return false;
            else
            {
                for (decimal i = 3; i < X; i += 2)
                {
                    if (X % i == 0) return false;
                }
                return true;
            }

            //1.慢
            //if (X <= 1) return false;
            //else
            //{
            //    for (decimal i = 2;i<X;i++)
            //    {
            //        if (X % i == 0) return false;
            //    }
            //    return true;
            //}
        }
    }
}
