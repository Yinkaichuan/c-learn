﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211007B
{
    class Program
    {
        static void Main(string[] args)
        {
            checked
            {
                while(true)
                {
                    Console.WriteLine("INPUT X?INPUT Y?");
                    String[] str = Console.ReadLine().Split(' ');
                    long X = long.Parse(str[0]);
                    long Y = long.Parse(str[1]);
                    Console.WriteLine("X+Y="+ (X+Y));
                    Console.WriteLine("X-Y=" + (X - Y));
                    Console.WriteLine("X*Y=" + (X * Y));
                    Console.WriteLine("X/Y=" + (X / Y));
                    Console.WriteLine("X%Y=" + (X % Y));
                    Console.WriteLine("X^Y=" + Math.Pow(X, Y));
                }

                //Console.WriteLine("INPUT X?INPUT Y?");
                //String[] str = Console.ReadLine().Split(' ');
                //String [] str= Console.ReadLine().Split('*'); //delimiter
                //Console.WriteLine(str[0] + str[1]);
                //Double X = Double.Parse(str[0]); //(double包含小數)
                //Double Y = Double.Parse(str[1]);

                //int X = int.Parse(str[0]); (int整數)
                //int Y = int.Parse(str[1]);

                //Console.WriteLine("X+Y="+ (X+Y));
                //Console.WriteLine("X-Y=" + (X - Y));
                //Console.WriteLine("X*Y=" + (X * Y));
                //Console.WriteLine("X/Y=" + (X / Y));
                //Console.WriteLine("X/Y(round)=" + Math.Round(X / Y,4));
                //Console.WriteLine("X%Y=" + (X % Y));
                //Console.WriteLine("X^Y=" + Math.Pow(X , Y));
                //Console.WriteLine("X^Y(round)=" + Math.Round(Math.Pow(X, Y),2));

                //Console.WriteLine("INPUT X?");
                //int X= int.Parse(Console.ReadLine());
                //Console.WriteLine("INPUT Y?");
                //int Y = int.Parse(Console.ReadLine());

                //Console.WriteLine("INPUT X?");
                //String X= Console.ReadLine();
                //Console.WriteLine("INPUT Y?");
                //String Y = Console.ReadLine();

                //Console.WriteLine("X+Y=" + (X + Y));
                //Console.ReadKey();


                //2.Variables(變數)
                //f(x,y)=x+y
                //f(4,5)=9
                //f(1,9)=10
                //2a.Defining Variables(declarartion,宣告資料型態)
                //int x;
                //int y;
                //int x, y;
                //2b.Initializing Variables
                //x = 4;
                //y = 9;
                //Console.WriteLine("x+y=" + (x + y));
                //x++;
                //y++;
                //Console.WriteLine("x+y=" + (x + y));
                //x = 92;
                //y = 80;
                //x--;
                //y--;
                //Console.WriteLine("x+y=" + (x + y));
                //long A, B;  (64bit)
                //A = 1234567890123456789;
                //B = 987654321012345679;
                //(結合)

                //long A = 1234567890123456789;
                //long B = 987654321012345678;
                //Console.WriteLine("A+B=" + (A + B));
                //Console.WriteLine("A*B=" + (A * B)); //(Overfiow溢位)

                //Console.WriteLine("*******+1=" + ( 2147483647+1)); (Overfiow溢位)
                //Console.WriteLine("*******+2=" + ((long)2147483647 + 2));

                //Console.ReadKey();

                //int C = 2147483647;
                //int D = 3;
                /*Console.WriteLine("C+D=" + (C + D));*/ //(Overfiow溢位)
                //Console.WriteLine("C+D=" + ((long)C + D));

                //1.Constant(常數)String(字串)
                //Console.Write("Ahoy! 110資一乙");
                //Console.WriteLine("Ahoy! 110IM1B");
                //Console.Write("Ahoy! pekora peko");
                //Console.WriteLine("Ahoy! 110IM1BBBB");
                //Console.WriteLine("11+9=" + (11 + 9));
                //Console.WriteLine("11-9=" + (11 - 9));
                //Console.WriteLine("11*9=" + (11 * 9));
                //Console.WriteLine("11+9=" + (11 + 9));
                //Console.WriteLine("11/9=" + (11 / 9));
                //Console.WriteLine("11.2/9.1=" + (11.2 / 9.1));
                //Console.WriteLine("11%9=" +(11 %9));
                //Console.WriteLine("3^12=" + Math.Pow(3,12));
                //Console.WriteLine("144^1/2=" + Math.Pow(144, 1.0/2.0));
                //Console.WriteLine("123456789*987654321=" +((long)12345678 * 987654321));
                //Console.ReadKey();
            }




        }
    }
}
