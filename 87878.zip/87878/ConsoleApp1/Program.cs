﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("[1]求介於兩個整數之間[2,501]因數(不含1與本身)與質數？？");
                    Console.WriteLine("[2]求介於兩個整數之間[0,9876543210]的Factorial、Fibonacci？？");
                    string[] line = Console.ReadLine().Split(' ');
                    decimal start;
                    decimal last;
                    switch (line[0])
                    {
                        case "1":
                            {

                                break;
                            }
                        case "2":
                            {
                                start = decimal.Parse(line[1]);
                                last = decimal.Parse(line[2]);
                                decimal temp;

                                if (start > last)
                                {
                                    temp = last;
                                    last = start;
                                    start = temp;
                                }
                                if (start<0)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("數字範圍[0,9876543210]錯誤");
                                    Console.ForegroundColor = ConsoleColor.White;
                                    break;
                                }
                                else if(last < 0)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("數字範圍[0,9876543210]錯誤");
                                    Console.ForegroundColor = ConsoleColor.White;
                                    break;
                                }
                                Console.WriteLine("Factorial(階乘)：");
                                for (int t = 0; Factorial(t) < 9999999999999999999; t++)
                                {
                                    if (Factorial(t) < start) continue;
                                    else if (Factorial(t) > last)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine(t + "!=" + Factorial(t));
                                        Console.ForegroundColor = ConsoleColor.White;
                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine(t + "!=" + Factorial(t));
                                    }

                                }
                                Console.WriteLine();
                                Console.WriteLine();
                                Console.WriteLine("Fibonacci Number(費氏數列)：");
                                for (int n = 0;Fibonacci(n)<= 9876543210; n++)
                                {
                                    if (Fibonacci(n) < start) continue;
                                    else if (Fibonacci(n)>last)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine("Fib(" + n + ") = " + Fibonacci(n));
                                        Console.ForegroundColor = ConsoleColor.White;
                                        break;
                                    }
                                    else { Console.WriteLine("Fib(" + n + ") = " + Fibonacci(n)); }

                                    if(Fibonacci(n)> 9876543210)
                                    {
                                        Console.WriteLine("");
                                    }

                                   


                                }
                                








                                break;
                            }
                    }
                }
                catch (Exception e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                finally
                {
                    Console.WriteLine("Press any key to Continue");
                }
            }
        }
        static decimal Factorial(int X)
        {
            decimal f;
            if (X < 0) return -1;
            else if (X == 0 || X == 1) return 1;
            else
            {
                f = 1;
                for (int i = X; i > 0; i--)
                {
                    f = f * i;
                }
                return f;
            }

        }
        static decimal Fibonacci(int X)
        {
            if (X < 0) return -1;
            else if (X == 0) return 0;
            else if (X == 1) return 1;
                else
                {
                    decimal f0 = 0;
                    decimal f1 = 1;
                    decimal fn = 0;
                    decimal f = 2;
                    while (f <= X)
                    {
                        fn = f0 + f1;
                        f0 = f1;
                        f1 = fn;
                        f++;
                    }
                    return fn;

            }
        }
    }
}
