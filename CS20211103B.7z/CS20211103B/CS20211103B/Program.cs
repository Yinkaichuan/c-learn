﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211103B
{
    class Program
    {
        static void Main(string[] args)
        {
            checked
            {
                double h =0, g = 9.80665, t = 0;
                    



                while (true) 
               {
                    try {

                        Console.WriteLine(System.DateTime.Now);
                        Console.Write("input 自由落體秒數=");
                        t = double.Parse(Console.ReadLine());
                        h=1.0/2.0*g*Math.Pow(t,2);
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine("吊橋高度="+Math.Round(h,2)+("公尺"));
                        Console.BackgroundColor = ConsoleColor.Black;
                        Console.ForegroundColor = ConsoleColor.White;

                    }
                    catch(Exception EX) 
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(EX);
                        //Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    finally
                    {
                        Console.WriteLine("Press any key for continue");
                        Console.ReadKey();
                    }
                        

                }

            }
        }
    }
}
