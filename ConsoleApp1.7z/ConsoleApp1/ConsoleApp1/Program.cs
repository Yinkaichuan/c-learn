﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true) 
            {
                try
                {
                    { 
                    Console.WriteLine("&(字串結合)；+(加法)；");
                    Console.WriteLine("*(乘法)；X(乘法：1234567890 X 98765432109)");
                    Console.WriteLine("/ (小數點三位)；＼(整除)");
                    Console.WriteLine("^(冪次方)；");
                    Console.WriteLine("Input Operator(&+*X /＼^)？ Two Operands(Integer)？？");

                    string[] a = Console.ReadLine().Split(' ');
                    if (a.Length != 3) continue;
                        checked
                        {
                            switch (a[0])
                            {
                                case "&":
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(a[1] + " & " + a[2] + " = " + (a[1] + a[2]));

                                    break;
                                case "+":
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(a[1] + " + " + a[2] + " = " + (int.Parse(a[1]) + int.Parse(a[2])));

                                    break;
                                case "*":
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(a[1] + " * " + a[2] + " = " );
                                    Console.WriteLine(long.Parse(a[1]) * long.Parse(a[2]));
                                    break;
                                case "X":
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(a[1] + " X " + a[2] + " = " + (decimal.Parse(a[1]) * decimal.Parse(a[2])));
                                    break;
                                case "/":
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(a[1] + " / " + a[2] + " = " + Math.Round(double.Parse(a[1]) / double.Parse(a[2]), 3));
                                    break;
                                case "＼":
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine(a[1] + " ＼ " + a[2] + " = " + (double.Parse(a[1]) / double.Parse(a[2])));
                                    break;
                                case "^":
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.Write(a[1] + " ^ " + a[2] + " = ");
                                    Console.WriteLine(Math.Pow(double.Parse(a[1]), double.Parse(a[2])));
                                    break;


                            }
                        }
                    }



                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write(ex.Message);
                    Console.WriteLine(";導致暫停");
                }
                finally
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("Hello！第一次程式小考。");
                    Console.ForegroundColor = ConsoleColor.White;
                }




            }        














        }
    }
}
