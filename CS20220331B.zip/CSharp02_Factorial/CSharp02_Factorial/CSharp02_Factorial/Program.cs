﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp02_Factorial
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {                    
                    Console.Write("Factorial？？");
                    string[] Line = Console.ReadLine().Split(' ');
                    if (Line[0] == "") break;                    
                    checked
                    {                       
                        int start = int.Parse(Line[0]);
                        int last =  int.Parse(Line[1]);
                        int temp;
                        if (start > last)    //Exchange the value of two Variables
                        {
                            temp = start;
                            start = last;
                            last = temp;
                        }
                        for (int n = start; n <= last; n++)
                        {
                            Console.WriteLine(n + "！= " + Factorial(n));
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e);
                    Console.ForegroundColor = ConsoleColor.White;
                }
                finally
                {
                    Console.WriteLine("Press any key to Exit");
                    Console.ReadKey();
                }
            }

        }

        static decimal Factorial(int X)
        {
            if (X < 0) return 0;
            else if (X == 0 || X == 1) return 1;
            else  //X > 1
            {
                decimal F = 1;
                for (int i = X; i > 0; i--)
                {
                    F *= i; //F = F * i;
                }
                return F;
            }

        }
    }
}
