﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20220325B
{
    internal class Eratostosnes
    {
        
            public int[] PrimeNo = new int[100001];
            //Eratostosnes PN = new Eratostosnes();
        
        public void Create()
        {


            PrimeNo[1] = 2; PrimeNo[2] = 3; PrimeNo[3] = 5; PrimeNo[4] = 7;
            int N = 11;
            int np, sr;

            Console.WriteLine("P1=2\n" + "P2=3\n" + "P3=5\n" + "P4=7\n");
            for (int n = 5; n <= 100000; n++)
            {
                sr = (int)Math.Sqrt(N) + 1;
                np = 1;
                while (sr >= PrimeNo[np])
                {
                    if (N % PrimeNo[np] == 0)
                    {
                        N++;
                        np = 1;
                    }
                    else np++;
                }
                PrimeNo[n] = N;
                N++;
            }
            Console.WriteLine("PrimeNO[1000]=" + PrimeNo[1000]);
            Console.WriteLine("PrimeNO[100000]=" + PrimeNo[100000]);
            Console.WriteLine("PrimeNO[100000]^2=" + (long)PrimeNo[100000] * (long)PrimeNo[100000]);
        }
        public bool Test(long N)
        {
            int ptr = 1;
            if (N < 2) return false;
            else if (N == 2) return true;
            else if (N % 2 == 0) return false;
            else
            {
                int sr = (int)Math.Sqrt(N) + 2;
                while (sr>PrimeNo[ptr])
                //while (PrimeNo[ptr] * (long)PrimeNo[ptr])
                {
                    if (N % PrimeNo[ptr] == 0) return false;
                    else ptr++;
                }

                return true;
            }
        }
    }
}

