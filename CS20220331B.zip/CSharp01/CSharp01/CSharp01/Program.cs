﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    checked
                    {
                        //Console.WriteLine("Input Number(Long)？？9223372036854775807 922337203");
                        //https://www.tutorialspoint.com/csharp/csharp_data_types.htm
                        Console.WriteLine("Input Number(Long)？？9223372036854775807 9223372036854775807");
                        string[] Line = Console.ReadLine().Split(' ');
                        if (Line[0] == "") break;
                        decimal X = decimal.Parse(Line[0]);
                        decimal Y = decimal.Parse(Line[1]);
                        //decimal X = long.MaxValue;
                        //decimal Y = long.MaxValue;
                        decimal Z = decimal.MaxValue;
                        Console.WriteLine("X = " + X);
                        Console.WriteLine("Y = " + Y);
                        Console.WriteLine("Z = " + Z);
                        Console.WriteLine("X ＋ Y = " + (X + Y));
                        Console.WriteLine("X * Y = " + (X * Y));
                        //Console.WriteLine("X * Y = " + ((decimal)X * (decimal)Y));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                finally
                {
                    Console.WriteLine("C# Finally Hello 明新資管甲乙班!!\n");
                }
            }
        }
    }
}
