﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211014B
{
    class Program
    {
        static void Main(string[] args)
        {
            checked
            {
                //Console.Write("好油喔 PEKO!!");
                //Console.WriteLine("ahoy!!");
                //Console.WriteLine("apex何時才能上大師?");

                
                Console.WriteLine("1+2+3+4+5=?" +1+2+3+4+5);
                Console.WriteLine("1+2+3+4+5=?" + (1+2+3+4+5));
                Console.WriteLine("(1+2+3+4+5)*5=?" + (1+2+3+4+5*5));
                Console.WriteLine("(1+2+3+4+5)*5=?" + ((1+2+3+4+5)*5));
                Console.WriteLine("(1+2+3+4+5)/5=?" + ((1+2+3+4+5)/5));

                Console.WriteLine("1/9=?" + (1/9));
                Console.WriteLine("1/9=?" + (1.0 / 9.0));
                Console.WriteLine("1/9=?(round)" + Math.Round(1.0 / 9.0,1));
                Console.WriteLine("1/9=?(round)" + Math.Round(1.0 / 9.0, 2));
                Console.WriteLine("1/9=?(round)" + Math.Round(1.0 / 9.0, 0));

                Console.WriteLine("1^9=?" + Math.Pow(19));

                Console.WriteLine("1%5=?" + (1 % 5));
                









                //int x = 1;
                //int y = 3;
                //Console.WriteLine("x+y=" + (x + y));
                //Console.WriteLine("x-y=" + (x - y));
                //Console.WriteLine("x*y=" + (x * y));
                //Console.WriteLine("x/y=" + (x / y));
                //Console.WriteLine("x^y=" + ma(xy));
                Console.ReadKey();
            }
        }
    }
}
