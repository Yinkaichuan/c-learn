﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211027B
{
    class Program
    {
        static void Main(string[] args)
        {
            checked
            {
                while (true) 
               {
                    //4.
                    Console.WriteLine("Input X? Input Y?");
                    string[] line = Console.ReadLine().Split(' ');
                    //Console.WriteLine(line[0]+ line[1]);
                    //Console.WriteLine(int.Parse(line[0]) + int.Parse(line[1])+ int.Parse(line[2]));
                    //Console.WriteLine(int.Parse(line[0]) * int.Parse(line[1]) - int.Parse(line[2]));


                    //int X = int.Parse(line[0]);
                    //int Y = int.Parse(line[1]);

                    //double X = double.Parse(line[0]);
                    //double Y = double.Parse(line[1]);


                    double X = double.Parse(line[0]), Y = double.Parse(line[1]);

                    Console.WriteLine("X+Y=" + (X + Y));
                    Console.WriteLine("X-Y=" + (X - Y));
                    Console.WriteLine("X*Y=" + (X * Y));
                    Console.WriteLine("X/Y=" + (X / Y));
                    Console.WriteLine("X%Y=" + (X % Y));
                    Console.WriteLine("X^Y=" + Math.Pow(X, Y));

                    Console.WriteLine("X/Y=" + Math.Round(X / Y, 3));
                    Console.WriteLine("X^Y=" + Math.Round(Math.Pow(X, Y), 3));


                    //3.Readline
                    //Console.WriteLine("Input = X");
                    //string X = Console.ReadLine();
                    //Console.WriteLine("Input = Y");
                    //string Y = Console.ReadLine();
                    //Console.WriteLine("X+Y=" +(X+Y));

                    //Console.WriteLine("Input = X");
                    //int X = int.Parse(Console.ReadLine());
                    //Console.WriteLine("Input = Y");
                    //int Y = int.Parse(Console.ReadLine());
                    //Console.WriteLine("X+Y=" + (X + Y));

                    //string Y = Console.ReadLine();
                    //Console.WriteLine("X+Y=" + (X + Y));


                    //2a.宣告

                    //int x;
                    //int y;

                    //2b.指派
                    //int x, y;
                    //x = 9;
                    //y = 10;
                    //Console.WriteLine("x+y=" + (x + y));

                    //int x = 9, y = 8;
                    //Console.WriteLine("x+y="+(x+y));

                    ////long a = 123456789012345678, b = 987654321098765432;
                    //decimal a = 123456789012345678, b = 987654321098765432;
                    //Console.WriteLine("a+b=" +(a+b));
                    //Console.WriteLine("a-b=" + (a - b));
                    ////Console.WriteLine("a*b=" + (a * b));
                    //Console.WriteLine("a/b=" + (a / b));

                    //int c= 2147483647;
                    //int d = 4;
                    //Console.WriteLine("c+d="+(c+d)); overflow
                    //Console.WriteLine("c-d="+(c-d));


                    // https://www.tutorialspoint.com/cprogramming/index.htm

                    //c#tutorial (Data type) (Variables)

                    Console.ReadKey();




                }









                


                
                
            }
        }
    }
}
