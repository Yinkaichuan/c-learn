﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211020C
{
    class Program
    {
        static void Main(string[] args)
        {
            checked
            {
                //Console.Write("好油喔 PEKO!!");
                //Console.WriteLine("ahoy!!");
                //Console.WriteLine("apex何時才能上大師?");


                //Console.WriteLine("1+2+3+4+5=?" + 1 + 2 + 3 + 4 + 5);
                //Console.WriteLine("1+2+3+4+5=?" + (1 + 2 + 3 + 4 + 5));
                //Console.WriteLine("(1+2+3+4+5)*5=?" + (1 + 2 + 3 + 4 + 5 * 5));
                //Console.WriteLine("(1+2+3+4+5)*5=?" + (1 + 2 + 3 + 4 + 5) * 5);
                //Console.WriteLine("(1+2+3+4+5)/5=?" + (1 + 2 + 3 + 4 + 5) / 5);


                //Console.WriteLine("1/9=?" + 1 / 9);
                //Console.WriteLine("1/9=?" + 1.0 / 9.0);


                //Console.WriteLine("1/9=(round)" + Math.Round(1.0 / 9.0, 1));
                //Console.WriteLine("1/9=(round)" + Math.Round(1.0 / 9.0, 2));
                //Console.WriteLine("1/9=(round)" + Math.Round(1.0 / 9.0, 0));

                //Console.Write("嗨 老師");
                //Console.WriteLine("3^9=" + Math.Pow(3, 9));
                //Console.WriteLine("12^12=" + Math.Pow(12, 12));
                //Console.WriteLine("144^1/2=" + Math.Pow(144, 1/2));
                //Console.WriteLine("144^1/2=" + Math.Pow(144, 1.0/2.0));

                Console.WriteLine("20%6=?" + 20 % 6);
                Console.WriteLine("30%9=?" + 30 % 9);

                //c#tutorial (data type)(Variables)
                Console.WriteLine("123*456="+(123*456));
                //Console.WriteLine("123456*654321=" + (123456 * 654321)); (溢位)

                Console.WriteLine("123456*654321=" + ((long)123456 * 654321));
                Console.WriteLine("123456*654321=" + (123456 * (long)654321));



                //int x = 1;
                //int y = 3;
                //Console.WriteLine("x+y=" + (x + y));
                //Console.WriteLine("x-y=" + (x - y));
                //Console.WriteLine("x*y=" + (x * y));
                //Console.WriteLine("x/y=" + (x / y));
                //Console.WriteLine("x^y=" + ma(xy));
                Console.ReadKey();
            }
        }
    }
}
