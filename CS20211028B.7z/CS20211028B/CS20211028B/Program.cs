﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20211028B
{
    class Program
    {
        static void Main(string[] args)
        {
            checked
            {
                while (true) 
               {
                    try {
                        Console.WriteLine("Input X? Input Y?");
                        string[] line = Console.ReadLine().Split(' ');

                        int X = int.Parse(line[0]);
                        int Y = int.Parse(line[1]);
                        //double X = double.Parse(line[0]);
                        //double Y = double.Parse(line[1]);
                        //int X = int.Parse(line[0]), Y = int.Parse(line[1]);
                        //double X = double.Parse(line[0]), Y = double.Parse(line[1]);

                        Console.WriteLine("X+Y=" + (X + Y));
                        Console.WriteLine("X-Y=" + (X - Y));
                        Console.WriteLine("X*Y=" + (X * Y));
                        Console.WriteLine("X/Y=" + (X / Y));
                        Console.WriteLine("X%Y=" + (X % Y));
                        Console.WriteLine("X^Y=" + Math.Pow(X, Y));

                        Console.WriteLine("X/Y=" + Math.Round((double)X / Y, 3));
                        Console.WriteLine("X^Y=" + Math.Round(Math.Pow(X, Y), 3));
                    }
                    catch(Exception EX) 
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(EX);
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    finally
                    {
                        Console.WriteLine("Press any key for continue");
                        Console.ReadKey();
                    }
                        

                }

            }
        }
    }
}
