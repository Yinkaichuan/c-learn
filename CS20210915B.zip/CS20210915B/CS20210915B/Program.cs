﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS20210915B
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ahoy! 110資一乙");
            Console.WriteLine("Ahoy! 110IM1B");
            Console.WriteLine("Ahoy! pekora peko");
            Console.Write("Ahoy! 110IM1BBBB");

            Console.ReadKey();
        }
    }
}
